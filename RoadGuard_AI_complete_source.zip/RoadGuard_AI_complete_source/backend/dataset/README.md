# Pothole dataset setup

The dataset is not included because image datasets can be large and have different licenses.

1. Find a pothole object-detection dataset from a reputable source such as Roboflow Universe or a research dataset repository.
2. Read its license and attribution requirements. Choose one that permits your hackathon/demo use.
3. Export it in YOLO/Ultralytics object-detection format.
4. Put it under `backend/dataset/potholes/` with `images/train`, `images/val`, and matching `labels/train`, `labels/val` folders. A test split is recommended.
5. Copy `data.yaml.example` to `data.yaml` and edit paths/class names as required.
6. From the `backend` folder run:

```bash
python train.py --data dataset/data.yaml --epochs 50 --imgsz 640
```

The script starts from `yolov8n.pt` and copies trained weights to `backend/models/best.pt`.

Do not claim the model is trained until training completes and it is tested on unseen images. Check license, labels, class names and split. The app's severity value is a rough bounding-box-area heuristic, not depth or actual road risk.
