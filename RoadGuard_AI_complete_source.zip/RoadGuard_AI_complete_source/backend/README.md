# RoadGuard AI backend

FastAPI + Ultralytics YOLO pothole-detection service. Python 3.10 or 3.11 is recommended.

## Install on Windows PowerShell
Open a terminal in this `backend` folder:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If activation is blocked, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.

## Dataset and training
Follow `dataset/README.md`. Download a properly licensed YOLO dataset and create `dataset/data.yaml`.

```powershell
python train.py --data dataset/data.yaml --epochs 50 --imgsz 640
```

Training time depends on your computer; a GPU helps but is not required for a small experiment.

## Start the API

```powershell
uvicorn app:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/docs`. Without `models/best.pt`, the API starts but `/api/detect` returns HTTP 503 explaining that trained weights are missing.

## Website connection
GitHub Pages serves only the frontend; it cannot run Python. The current HTML demo has not yet been wired to this API. For local testing, configure a local frontend to use `http://127.0.0.1:8000`. For a public demo, deploy this API to a Python host with HTTPS and connect the frontend to that URL.

`POST /api/detect` accepts multipart field `image` (JPG/PNG/WEBP) and optional `confidence` query parameter (0.05–0.95). It returns detections and a base64 annotated image.

Safety: this is a hackathon prototype, not a certified inspection system. Severity is a bounding-box-area estimate only, not pothole depth or structural risk. Every report needs human verification.
