Place your trained YOLO weights here as `best.pt` after training. Model weights are excluded from Git because they can be large.
